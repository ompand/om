function togglePortfolioField() {
    var role = document.getElementById("role").value;
    var extraFields = document.getElementById("extraFields");

    if (role === "Video Editor" || role === "Graphic Designer") {
        extraFields.style.display = "block";
    } else {
        extraFields.style.display = "none";
    }
}
