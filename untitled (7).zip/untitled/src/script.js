function togglePortfolioField() {
    var role = document.getElementById("role").value;
    var portfolioField = document.getElementById("portfolioField");

    if (role === "Video Editor" || role === "Graphic Designer") {
        portfolioField.style.display = "block";
    } else {
        portfolioField.style.display = "none";
    }
}
